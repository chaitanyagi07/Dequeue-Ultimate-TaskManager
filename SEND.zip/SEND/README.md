# Dequeue-Task-Manager
Deque is your ultimate one stop solution for your 4 problems 
